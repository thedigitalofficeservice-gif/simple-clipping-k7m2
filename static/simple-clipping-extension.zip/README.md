# Simple Clipping Helper (Chrome extension)

Makes YouTube links work reliably in Simple Clipping.

Why: YouTube blocks video downloads from the clipping server, and it also
blocks a plain web page from fetching the video. This small extension runs
in YOUR browser, so the video is downloaded using YOUR home connection
(which YouTube does not block), then uploaded to the clipping server.
No login, no account, no password. It only talks to youtube.com,
googlevideo.com and the Simple Clipping server.

## Install (one time, free, about 1 minute)

1. Download `simple-clipping-extension.zip` and unzip it. You get a folder
   with `manifest.json`, `content.js` and this README.
2. In Chrome, open `chrome://extensions`
3. Turn ON "Developer mode" (top right).
4. Click "Load unpacked" and pick the unzipped folder.
5. Open the Simple Clipping site, paste a YouTube link and press
   Start Clipping. The page will use the helper automatically.
   (If the helper is not installed, the page falls back to the old
   behaviour: it tries the browser, then the server.)

## To remove it later

`chrome://extensions` → Remove.

## What it does, exactly

- `content.js` runs only on the Simple Clipping site.
- When the page asks for a YouTube video, it calls YouTube's own player
  API (the same public key YouTube's own pages use), picks the best
  progressive MP4 up to 720p, downloads it in your browser, and uploads
  it to the Simple Clipping server (`/api/jobs`) for clipping.
- It never reads your YouTube account, cookies, history or passwords.
