// Simple Clipping Helper — content script.
// Runs on the Simple Clipping page. When the page asks for a YouTube
// video, this script fetches it from YouTube using YOUR home connection
// (an extension is allowed to contact youtube.com directly — a plain
// web page is not, because YouTube does not allow that request from
// other sites), then uploads the downloaded video to the Simple Clipping
// server for clipping, and hands the job id back to the page.
// No login, no cookies, no account. The only key used is YouTube's own
// public web-client key, the same one its own pages use.
(function () {
  "use strict";

  // Tell the page the helper is installed (shared DOM attribute).
  document.documentElement.setAttribute("data-sc-ext", "ready");

  var YT_API_KEY = "AIzaSyAO_FJ2SlqU8Q4STEHLGCilw_Y9_11qcW8";
  var CLIPPER = "https://simple-clipping-k7m2-production.up.railway.app";

  function ytVideoId(url) {
    var m = String(url || "").match(/(?:youtube\.com\/(?:watch\?[^#]*v=|live\/|shorts\/|embed\/|v\/)|youtu\.be\/)([A-Za-z0-9_-]{11})/);
    return m ? m[1] : null;
  }

  function postNote(requestId, note) {
    window.postMessage({ type: "SC_FETCH_YOUTUBE_NOTE", requestId: requestId, note: note }, "*");
  }

  async function fetchAndUpload(url, requestId) {
    var vid = ytVideoId(url);
    if (!vid) throw new Error("That does not look like a YouTube link.");
    postNote(requestId, "Helper extension: fetching the video with your home connection...");
    var r = await fetch("https://www.youtube.com/youtubei/v1/player?key=" + YT_API_KEY, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        context: { client: { clientName: "ANDROID", clientVersion: "20.10.38", androidSdkVersion: 30, hl: "en", gl: "US" } },
        videoId: vid,
        playbackContext: { contentPlaybackContext: { vis: 0, splay: false, lact: [] } }
      })
    });
    if (!r.ok) throw new Error("YouTube answered " + r.status + ".");
    var data = await r.json();
    if ((data.playabilityStatus || {}).status !== "OK") {
      throw new Error("YouTube will not play this video here (" + ((data.playabilityStatus || {}).status || "unknown") + ").");
    }
    var sd = data.streamingData || {};
    var formats = (sd.formats || []).concat(sd.adaptiveFormats || []);
    var prog = formats.filter(function (f) {
      return f.mimeType && f.mimeType.indexOf("video/mp4") !== -1 && f.url && f.height && f.height <= 720;
    });
    prog.sort(function (a, b) { return (b.height || 0) - (a.height || 0); });
    if (!prog.length) throw new Error("No downloadable video stream found.");
    postNote(requestId, "Found a " + prog[0].height + "p stream, downloading it in your browser...");
    var vr = await fetch(prog[0].url);
    if (!vr.ok) throw new Error("The video download failed (" + vr.status + ").");
    var blob = await vr.blob();
    if (!blob || blob.size < 100000) throw new Error("The downloaded video was empty.");
    postNote(requestId, "Downloaded " + (blob.size / 1024 / 1024).toFixed(1) + " MB in your browser, uploading it for clipping...");
    var fd = new FormData();
    fd.append("upload", new File([blob], "youtube-" + vid + ".mp4", { type: "video/mp4" }));
    var jr = await fetch(CLIPPER + "/api/jobs", { method: "POST", body: fd });
    if (!jr.ok) {
      var t = "";
      try { t = await jr.text(); } catch (e) {}
      throw new Error("Upload failed: " + (t || jr.statusText));
    }
    var job = await jr.json();
    if (!job || !job.id) throw new Error("The server did not return a job.");
    return job.id;
  }

  window.addEventListener("message", function (event) {
    if (event.source !== window) return;
    var d = event.data || {};
    if (d.type !== "SC_FETCH_YOUTUBE") return;
    fetchAndUpload(d.url, d.requestId).then(function (jobId) {
      window.postMessage({ type: "SC_FETCH_YOUTUBE_RESULT", requestId: d.requestId, ok: true, jobId: jobId }, "*");
    }).catch(function (e) {
      window.postMessage({ type: "SC_FETCH_YOUTUBE_RESULT", requestId: d.requestId, ok: false, error: (e && e.message) || String(e) }, "*");
    });
  });
})();
